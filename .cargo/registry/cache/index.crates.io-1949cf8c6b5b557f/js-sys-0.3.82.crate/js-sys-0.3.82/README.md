# `js-sys`

[API documentation](https://wasm-bindgen.github.io/wasm-bindgen/api/js_sys/)

Raw bindings to JS global APIs for projects using `wasm-bindgen`. This crate is
handwritten and intended to work in *all* JS environments like browsers and
Node.js.
